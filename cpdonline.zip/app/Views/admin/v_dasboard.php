<?= $this->extend('template/v_backend') ?>
<?= $this->section('content') ?>
<h1>ini dashboard</h1>

<?= $this->endSection() ?>